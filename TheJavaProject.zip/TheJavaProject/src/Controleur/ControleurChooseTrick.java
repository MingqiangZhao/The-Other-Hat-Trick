package Controleur;

public class ControleurChooseTrick {

}
