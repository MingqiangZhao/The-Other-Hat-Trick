package TheOtherHatTrick;
/**
 * @author Mingqiang
 */
import javax.swing.ImageIcon;

public class ImageCard {
    public static ImageIcon c1 = new ImageIcon("img\\carrot.png");
	
	public static ImageIcon c2 = new ImageIcon("img\\hat.png");
	public static ImageIcon c3 = new ImageIcon("img\\lettuce.png");
	public static ImageIcon c4 = new ImageIcon("img\\otherRabbit.png");
	public static ImageIcon c5 = new ImageIcon("img\\rabbit.png");
	
	public static ImageIcon c6 = new ImageIcon("img\\theBunchofCarrots.png");
	public static ImageIcon c7 = new ImageIcon("img\\theCarrotHatTrick.png");
	public static ImageIcon c8 = new ImageIcon("img\\theHatTrick.png");
	public static ImageIcon c9 = new ImageIcon("img\\theHungryRabbit.png");
	public static ImageIcon c10 = new ImageIcon("img\\theOtherHatTrick.png");
	public static ImageIcon c11 = new ImageIcon("img\\thePairofRabbits.png");
	public static ImageIcon c12 = new ImageIcon("img\\theRabbitThatDidntLikeCarrots.png");
	public static ImageIcon c13 = new ImageIcon("img\\theSlightlyEasierHatTrick.png");
	public static ImageIcon c14 = new ImageIcon("img\\theVegetableHatTrick.png");
	public static ImageIcon c15 = new ImageIcon("img\\theVegetablePatch.png");
	
	public static ImageIcon c16 = new ImageIcon("img\\cardBack.png");
    
}
