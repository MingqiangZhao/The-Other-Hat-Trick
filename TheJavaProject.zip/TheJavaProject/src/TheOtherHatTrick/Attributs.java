package TheOtherHatTrick;
/**
 * 
 * @author Mingqiang
 *
 */
public enum Attributs {
     TheRabbit,
     TheOtherRabbit,
     TheHat,
     TheCarrots,
     TheLecttuce;
}
